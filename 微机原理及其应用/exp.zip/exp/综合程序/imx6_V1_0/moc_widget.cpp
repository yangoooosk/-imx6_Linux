/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[47];
    char stringdata0[1146];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Widget"
QT_MOC_LITERAL(1, 7, 19), // "billboardPressEvent"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 1), // "a"
QT_MOC_LITERAL(4, 30, 12), // "SwitchSignal"
QT_MOC_LITERAL(5, 43, 12), // "getKeySignal"
QT_MOC_LITERAL(6, 56, 1), // "n"
QT_MOC_LITERAL(7, 58, 15), // "mousePressEvent"
QT_MOC_LITERAL(8, 74, 12), // "QMouseEvent*"
QT_MOC_LITERAL(9, 87, 5), // "event"
QT_MOC_LITERAL(10, 93, 17), // "mouseReleaseEvent"
QT_MOC_LITERAL(11, 111, 25), // "on_homePageButton_clicked"
QT_MOC_LITERAL(12, 137, 27), // "on_cameraPageButton_clicked"
QT_MOC_LITERAL(13, 165, 30), // "on_billboardPageButton_clicked"
QT_MOC_LITERAL(14, 196, 26), // "on_snakePageButton_clicked"
QT_MOC_LITERAL(15, 223, 25), // "on_itmsPageButton_clicked"
QT_MOC_LITERAL(16, 249, 32), // "on_trackingCarPageButton_clicked"
QT_MOC_LITERAL(17, 282, 26), // "on_homePageButton1_clicked"
QT_MOC_LITERAL(18, 309, 24), // "on_ledPageButton_clicked"
QT_MOC_LITERAL(19, 334, 31), // "on_billboardPageButton1_clicked"
QT_MOC_LITERAL(20, 366, 27), // "on_snakePageButton1_clicked"
QT_MOC_LITERAL(21, 394, 26), // "on_itmsPageButton1_clicked"
QT_MOC_LITERAL(22, 421, 33), // "on_trackingCarPageButton1_cli..."
QT_MOC_LITERAL(23, 455, 26), // "on_homePageButton2_clicked"
QT_MOC_LITERAL(24, 482, 25), // "on_ledPageButton1_clicked"
QT_MOC_LITERAL(25, 508, 28), // "on_cameraPageButton1_clicked"
QT_MOC_LITERAL(26, 537, 27), // "on_snakePageButton2_clicked"
QT_MOC_LITERAL(27, 565, 26), // "on_itmsPageButton2_clicked"
QT_MOC_LITERAL(28, 592, 33), // "on_trackingCarPageButton2_cli..."
QT_MOC_LITERAL(29, 626, 26), // "on_homePageButton3_clicked"
QT_MOC_LITERAL(30, 653, 25), // "on_ledPageButton2_clicked"
QT_MOC_LITERAL(31, 679, 28), // "on_cameraPageButton2_clicked"
QT_MOC_LITERAL(32, 708, 31), // "on_billboardPageButton2_clicked"
QT_MOC_LITERAL(33, 740, 26), // "on_itmsPageButton3_clicked"
QT_MOC_LITERAL(34, 767, 33), // "on_trackingCarPageButton3_cli..."
QT_MOC_LITERAL(35, 801, 26), // "on_homePageButton4_clicked"
QT_MOC_LITERAL(36, 828, 25), // "on_ledPageButton3_clicked"
QT_MOC_LITERAL(37, 854, 28), // "on_cameraPageButton3_clicked"
QT_MOC_LITERAL(38, 883, 31), // "on_billboardPageButton3_clicked"
QT_MOC_LITERAL(39, 915, 27), // "on_snakePageButton3_clicked"
QT_MOC_LITERAL(40, 943, 33), // "on_trackingCarPageButton4_cli..."
QT_MOC_LITERAL(41, 977, 26), // "on_homePageButton5_clicked"
QT_MOC_LITERAL(42, 1004, 25), // "on_ledPageButton4_clicked"
QT_MOC_LITERAL(43, 1030, 28), // "on_cameraPageButton4_clicked"
QT_MOC_LITERAL(44, 1059, 31), // "on_billboardPageButton4_clicked"
QT_MOC_LITERAL(45, 1091, 27), // "on_snakePageButton4_clicked"
QT_MOC_LITERAL(46, 1119, 26) // "on_itmsPageButton4_clicked"

    },
    "Widget\0billboardPressEvent\0\0a\0"
    "SwitchSignal\0getKeySignal\0n\0mousePressEvent\0"
    "QMouseEvent*\0event\0mouseReleaseEvent\0"
    "on_homePageButton_clicked\0"
    "on_cameraPageButton_clicked\0"
    "on_billboardPageButton_clicked\0"
    "on_snakePageButton_clicked\0"
    "on_itmsPageButton_clicked\0"
    "on_trackingCarPageButton_clicked\0"
    "on_homePageButton1_clicked\0"
    "on_ledPageButton_clicked\0"
    "on_billboardPageButton1_clicked\0"
    "on_snakePageButton1_clicked\0"
    "on_itmsPageButton1_clicked\0"
    "on_trackingCarPageButton1_clicked\0"
    "on_homePageButton2_clicked\0"
    "on_ledPageButton1_clicked\0"
    "on_cameraPageButton1_clicked\0"
    "on_snakePageButton2_clicked\0"
    "on_itmsPageButton2_clicked\0"
    "on_trackingCarPageButton2_clicked\0"
    "on_homePageButton3_clicked\0"
    "on_ledPageButton2_clicked\0"
    "on_cameraPageButton2_clicked\0"
    "on_billboardPageButton2_clicked\0"
    "on_itmsPageButton3_clicked\0"
    "on_trackingCarPageButton3_clicked\0"
    "on_homePageButton4_clicked\0"
    "on_ledPageButton3_clicked\0"
    "on_cameraPageButton3_clicked\0"
    "on_billboardPageButton3_clicked\0"
    "on_snakePageButton3_clicked\0"
    "on_trackingCarPageButton4_clicked\0"
    "on_homePageButton5_clicked\0"
    "on_ledPageButton4_clicked\0"
    "on_cameraPageButton4_clicked\0"
    "on_billboardPageButton4_clicked\0"
    "on_snakePageButton4_clicked\0"
    "on_itmsPageButton4_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      41,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  219,    2, 0x06 /* Public */,
       4,    1,  222,    2, 0x06 /* Public */,
       5,    1,  225,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,  228,    2, 0x09 /* Protected */,
      10,    1,  231,    2, 0x09 /* Protected */,
      11,    0,  234,    2, 0x08 /* Private */,
      12,    0,  235,    2, 0x08 /* Private */,
      13,    0,  236,    2, 0x08 /* Private */,
      14,    0,  237,    2, 0x08 /* Private */,
      15,    0,  238,    2, 0x08 /* Private */,
      16,    0,  239,    2, 0x08 /* Private */,
      17,    0,  240,    2, 0x08 /* Private */,
      18,    0,  241,    2, 0x08 /* Private */,
      19,    0,  242,    2, 0x08 /* Private */,
      20,    0,  243,    2, 0x08 /* Private */,
      21,    0,  244,    2, 0x08 /* Private */,
      22,    0,  245,    2, 0x08 /* Private */,
      23,    0,  246,    2, 0x08 /* Private */,
      24,    0,  247,    2, 0x08 /* Private */,
      25,    0,  248,    2, 0x08 /* Private */,
      26,    0,  249,    2, 0x08 /* Private */,
      27,    0,  250,    2, 0x08 /* Private */,
      28,    0,  251,    2, 0x08 /* Private */,
      29,    0,  252,    2, 0x08 /* Private */,
      30,    0,  253,    2, 0x08 /* Private */,
      31,    0,  254,    2, 0x08 /* Private */,
      32,    0,  255,    2, 0x08 /* Private */,
      33,    0,  256,    2, 0x08 /* Private */,
      34,    0,  257,    2, 0x08 /* Private */,
      35,    0,  258,    2, 0x08 /* Private */,
      36,    0,  259,    2, 0x08 /* Private */,
      37,    0,  260,    2, 0x08 /* Private */,
      38,    0,  261,    2, 0x08 /* Private */,
      39,    0,  262,    2, 0x08 /* Private */,
      40,    0,  263,    2, 0x08 /* Private */,
      41,    0,  264,    2, 0x08 /* Private */,
      42,    0,  265,    2, 0x08 /* Private */,
      43,    0,  266,    2, 0x08 /* Private */,
      44,    0,  267,    2, 0x08 /* Private */,
      45,    0,  268,    2, 0x08 /* Private */,
      46,    0,  269,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPoint,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::ULong,    6,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Widget *_t = static_cast<Widget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->billboardPressEvent((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 1: _t->SwitchSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->getKeySignal((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 3: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->mouseReleaseEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 5: _t->on_homePageButton_clicked(); break;
        case 6: _t->on_cameraPageButton_clicked(); break;
        case 7: _t->on_billboardPageButton_clicked(); break;
        case 8: _t->on_snakePageButton_clicked(); break;
        case 9: _t->on_itmsPageButton_clicked(); break;
        case 10: _t->on_trackingCarPageButton_clicked(); break;
        case 11: _t->on_homePageButton1_clicked(); break;
        case 12: _t->on_ledPageButton_clicked(); break;
        case 13: _t->on_billboardPageButton1_clicked(); break;
        case 14: _t->on_snakePageButton1_clicked(); break;
        case 15: _t->on_itmsPageButton1_clicked(); break;
        case 16: _t->on_trackingCarPageButton1_clicked(); break;
        case 17: _t->on_homePageButton2_clicked(); break;
        case 18: _t->on_ledPageButton1_clicked(); break;
        case 19: _t->on_cameraPageButton1_clicked(); break;
        case 20: _t->on_snakePageButton2_clicked(); break;
        case 21: _t->on_itmsPageButton2_clicked(); break;
        case 22: _t->on_trackingCarPageButton2_clicked(); break;
        case 23: _t->on_homePageButton3_clicked(); break;
        case 24: _t->on_ledPageButton2_clicked(); break;
        case 25: _t->on_cameraPageButton2_clicked(); break;
        case 26: _t->on_billboardPageButton2_clicked(); break;
        case 27: _t->on_itmsPageButton3_clicked(); break;
        case 28: _t->on_trackingCarPageButton3_clicked(); break;
        case 29: _t->on_homePageButton4_clicked(); break;
        case 30: _t->on_ledPageButton3_clicked(); break;
        case 31: _t->on_cameraPageButton3_clicked(); break;
        case 32: _t->on_billboardPageButton3_clicked(); break;
        case 33: _t->on_snakePageButton3_clicked(); break;
        case 34: _t->on_trackingCarPageButton4_clicked(); break;
        case 35: _t->on_homePageButton5_clicked(); break;
        case 36: _t->on_ledPageButton4_clicked(); break;
        case 37: _t->on_cameraPageButton4_clicked(); break;
        case 38: _t->on_billboardPageButton4_clicked(); break;
        case 39: _t->on_snakePageButton4_clicked(); break;
        case 40: _t->on_itmsPageButton4_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (Widget::*_t)(QPoint );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Widget::billboardPressEvent)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Widget::SwitchSignal)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Widget::*_t)(unsigned long );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Widget::getKeySignal)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject Widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Widget.data,
      qt_meta_data_Widget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 41)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 41;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 41)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 41;
    }
    return _id;
}

// SIGNAL 0
void Widget::billboardPressEvent(QPoint _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Widget::SwitchSignal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Widget::getKeySignal(unsigned long _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
