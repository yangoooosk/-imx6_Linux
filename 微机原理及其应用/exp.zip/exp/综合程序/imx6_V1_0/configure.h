#ifndef CONFIGURE
#define CONFIGURE

//============================滑动识别=============
extern unsigned char pagesize;        //总共页面数
extern int pagenum; //当前页面






















#endif // CONFIGURE

