#include <stdio.h>
#include <fcntl.h>

int main()
{
	printf("hello world \n");
	return 0;
}
