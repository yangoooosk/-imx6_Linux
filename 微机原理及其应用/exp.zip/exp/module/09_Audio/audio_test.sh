aplay 1.wav
